/**
 * loader.js — HTML Section Loader
 * ================================
 * Fetches each section file and injects it into the DOM
 * before main.js runs. All [data-include] placeholders
 * are replaced in order, then main.js is initialized.
 *
 * Usage: <div data-include="sections/nav.html"></div>
 *
 * NOTE: Requires a local server (e.g. VS Code Live Server,
 *       Python http.server, or Node serve) because browsers
 *       block fetch() for local file:// URLs.
 *
 * Quick start:
 *   npx serve .         (Node)
 *   python -m http.server 8080   (Python)
 *   VS Code → "Go Live" button
 */

(function () {
  'use strict';

  /**
   * Fetch and inject a single section.
   * @param {HTMLElement} placeholder - The div[data-include] element
   * @returns {Promise<void>}
   */
  async function loadSection(placeholder) {
    const url = placeholder.getAttribute('data-include');
    if (!url) return;

    try {
      const response = await fetch(url);
      if (!response.ok) {
        console.error(`[Loader] Failed to load: ${url} (${response.status})`);
        placeholder.innerHTML = `<div style="color:red;padding:20px;">
          ⚠️ Could not load section: <code>${url}</code><br>
          <small>Make sure you're running this via a local server, not file://</small>
        </div>`;
        return;
      }

      const html = await response.text();

      // Create a temporary container to parse the HTML
      const temp = document.createElement('div');
      temp.innerHTML = html;

      // Replace the placeholder with the loaded content
      placeholder.replaceWith(...temp.childNodes);

    } catch (err) {
      console.error(`[Loader] Error loading ${url}:`, err);
      placeholder.innerHTML = `<div style="color:red;padding:20px;">
        ⚠️ Network error loading: <code>${url}</code>
      </div>`;
    }
  }

  /**
   * Load all sections sequentially to preserve DOM order,
   * then dispatch a custom event so main.js knows to init.
   */
  async function loadAllSections() {
    const placeholders = Array.from(
      document.querySelectorAll('[data-include]')
    );

    // Load sequentially — keeps section order guaranteed
    for (const placeholder of placeholders) {
      await loadSection(placeholder);
    }

    // Signal that DOM is fully assembled
    document.dispatchEvent(new CustomEvent('sections:ready'));
    console.log('[Loader] All sections loaded ✓');
  }

  // Start as soon as DOM is parsed
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', loadAllSections);
  } else {
    loadAllSections();
  }

})();
