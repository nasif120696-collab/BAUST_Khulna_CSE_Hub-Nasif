/**
 * main.js — App Logic
 * ====================
 * All DOM-dependent code waits for the 'sections:ready' event
 * dispatched by loader.js once all section HTML is injected.
 *
 * Theme is applied immediately (before sections load) to prevent
 * a flash of unstyled theme.
 */

// ─────────────────────────────────────────
// IMMEDIATE: Apply saved theme (no DOM needed)
// ─────────────────────────────────────────
(function () {
  const saved = localStorage.getItem('theme');
  const prefersDark = window.matchMedia('(prefers-color-scheme:dark)').matches;
  const theme = saved || (prefersDark ? 'dark' : 'light');
  document.documentElement.setAttribute('data-theme', theme);
})();

// ─────────────────────────────────────────
// DEFERRED: Everything else runs after all
// section HTML has been injected into the DOM
// ─────────────────────────────────────────
document.addEventListener('sections:ready', function () {

  // Update theme button icon now that nav is in the DOM
  const themeBtn = document.getElementById('themeBtn');
  if (themeBtn) {
    themeBtn.textContent = document.documentElement.getAttribute('data-theme') === 'dark' ? '☀️' : '🌙';
  }

// ===== THEME TOGGLE =====
function toggleTheme(){
  const html=document.documentElement;
  const isDark=html.getAttribute('data-theme')==='dark';
  html.setAttribute('data-theme',isDark?'light':'dark');
  document.getElementById('themeBtn').textContent=isDark?'🌙':'☀️';
  localStorage.setItem('theme',isDark?'light':'dark');
}
// [theme IIFE moved to top of file]

// ===== PREMIUM CANVAS PARTICLE SYSTEM =====
(function(){
  const canvas=document.getElementById('heroCanvas');
  if(!canvas)return;
  const ctx=canvas.getContext('2d');
  let W,H,particles=[],mouse={x:-999,y:-999};

  function resize(){
    W=canvas.width=canvas.offsetWidth;
    H=canvas.height=canvas.offsetHeight;
  }
  resize();
  window.addEventListener('resize',resize);

  function isDark(){return document.documentElement.getAttribute('data-theme')==='dark';}

  function createParticles(){
    particles=[];
    const count=Math.min(60,Math.floor(W*H/14000));
    for(let i=0;i<count;i++){
      particles.push({
        x:Math.random()*W,y:Math.random()*H,
        vx:(Math.random()-0.5)*0.4,vy:(Math.random()-0.5)*0.4,
        r:Math.random()*2+0.8,
        opacity:Math.random()*0.5+0.1,
        hue:Math.random()*60-20 // offset from base hue
      });
    }
  }
  createParticles();
  document.addEventListener('themeChanged',createParticles);

  function drawParticles(){
    ctx.clearRect(0,0,W,H);
    const dark=isDark();
    const baseColor=dark?'56,189,248':'3,105,161';
    const accentColor=dark?'129,140,248':'99,102,241';

    // Draw connections
    for(let i=0;i<particles.length;i++){
      for(let j=i+1;j<particles.length;j++){
        const dx=particles[i].x-particles[j].x;
        const dy=particles[i].y-particles[j].y;
        const dist=Math.sqrt(dx*dx+dy*dy);
        if(dist<120){
          const alpha=(1-dist/120)*0.18;
          ctx.beginPath();
          ctx.strokeStyle=`rgba(${baseColor},${alpha})`;
          ctx.lineWidth=0.6;
          ctx.moveTo(particles[i].x,particles[i].y);
          ctx.lineTo(particles[j].x,particles[j].y);
          ctx.stroke();
        }
      }
    }

    // Draw particles + mouse interaction
    particles.forEach(p=>{
      const mdx=p.x-mouse.x; const mdy=p.y-mouse.y;
      const md=Math.sqrt(mdx*mdx+mdy*mdy);
      if(md<120){
        p.vx+=mdx/md*0.08;
        p.vy+=mdy/md*0.08;
      }
      p.vx*=0.98; p.vy*=0.98;
      p.x+=p.vx; p.y+=p.vy;
      if(p.x<0)p.x=W; if(p.x>W)p.x=0;
      if(p.y<0)p.y=H; if(p.y>H)p.y=0;

      const col=Math.random()>0.5?baseColor:accentColor;
      ctx.beginPath();
      ctx.arc(p.x,p.y,p.r,0,Math.PI*2);
      ctx.fillStyle=`rgba(${col},${p.opacity})`;
      ctx.fill();
    });

    requestAnimationFrame(drawParticles);
  }
  drawParticles();

  canvas.closest('.hero').addEventListener('mousemove',e=>{
    const rect=canvas.getBoundingClientRect();
    mouse.x=e.clientX-rect.left;
    mouse.y=e.clientY-rect.top;
  });
  canvas.closest('.hero').addEventListener('mouseleave',()=>{mouse.x=-999;mouse.y=-999;});
})();

// ===== CUSTOM CURSOR =====
(function(){
  const glow=document.getElementById('cursor-glow');
  const dot=document.getElementById('cursor-dot');
  if(!glow||!dot)return;
  let mx=0,my=0,gx=0,gy=0;
  document.addEventListener('mousemove',e=>{mx=e.clientX;my=e.clientY;});
  document.addEventListener('mouseleave',()=>{glow.style.opacity='0';dot.style.opacity='0';});
  document.addEventListener('mouseenter',()=>{glow.style.opacity='1';dot.style.opacity='1';});
  function animCursor(){
    gx+=(mx-gx)*0.1; gy+=(my-gy)*0.1;
    glow.style.left=gx+'px'; glow.style.top=gy+'px';
    dot.style.left=mx+'px'; dot.style.top=my+'px';
    requestAnimationFrame(animCursor);
  }
  animCursor();

  // Cursor scale on hoverable elements
  document.querySelectorAll('a,button,.btn,.rcard,.sem-hdr,.tab,.rcard').forEach(el=>{
    el.addEventListener('mouseenter',()=>{dot.style.width='18px';dot.style.height='18px';dot.style.opacity='0.6';});
    el.addEventListener('mouseleave',()=>{dot.style.width='8px';dot.style.height='8px';dot.style.opacity='1';});
  });
})();

// ===== PROGRESS BAR =====
window.addEventListener('scroll',()=>{
  const s=document.documentElement.scrollTop;
  const h=document.documentElement.scrollHeight-window.innerHeight;
  document.getElementById('pbar').style.width=(s/h*100)+'%';
});

// ===== PREMIUM SCROLL REVEAL + COUNTERS + SECTION HEADERS =====
(function(){
  // Animated counter helper
  function animateCounter(el){
    const text=el.textContent.trim();
    const match=text.match(/^(\d+)(\+|k|\+?)?$/);
    if(!match)return;
    const target=parseInt(match[1]);
    const suffix=match[2]||'';
    let start=0;
    const duration=1400;
    const startTime=performance.now();
    function step(now){
      const elapsed=now-startTime;
      const progress=Math.min(elapsed/duration,1);
      const eased=1-Math.pow(1-progress,3); // cubic ease-out
      const current=Math.round(eased*target);
      el.textContent=current+suffix;
      if(progress<1)requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }

  // Main intersection observer
  const ro=new IntersectionObserver(e=>e.forEach(x=>{
    if(!x.isIntersecting)return;
    const el=x.target;
    el.classList.add('visible');

    // Animated counters inside stats
    if(el.classList.contains('visible')){
      el.querySelectorAll('.snum').forEach(sn=>{
        if(!sn.dataset.counted){sn.dataset.counted='1';animateCounter(sn);}
      });
    }

    // Section header accent line
    if(el.classList.contains('sec-hdr')){
      setTimeout(()=>el.classList.add('line-active'),300);
    }

    ro.unobserve(el);
  }),{threshold:0.08,rootMargin:'0px 0px -40px 0px'});

  document.querySelectorAll('.reveal,.reveal-left,.reveal-right,.reveal-scale').forEach(el=>ro.observe(el));

  // Stagger observer
  const staggerObs=new IntersectionObserver(e=>e.forEach(x=>{
    if(!x.isIntersecting)return;
    x.target.classList.add('visible');
    // Animate counters in stagger containers
    x.target.querySelectorAll('.snum').forEach(sn=>{
      if(!sn.dataset.counted){sn.dataset.counted='1';animateCounter(sn);}
    });
    staggerObs.unobserve(x.target);
  }),{threshold:0.1});
  document.querySelectorAll('.stagger').forEach(el=>staggerObs.observe(el));
})();

// ===== RIPPLE ON BUTTONS =====
document.querySelectorAll('.btn').forEach(btn=>{
  btn.addEventListener('click',function(e){
    const r=document.createElement('span');
    r.className='ripple-effect';
    const rect=btn.getBoundingClientRect();
    const size=Math.max(rect.width,rect.height)*2;
    r.style.cssText=`width:${size}px;height:${size}px;left:${e.clientX-rect.left-size/2}px;top:${e.clientY-rect.top-size/2}px;`;
    btn.appendChild(r);
    setTimeout(()=>r.remove(),700);
  });
});

// ===== ACTIVE NAV HIGHLIGHT ON SCROLL =====
(function(){
  const sections=document.querySelectorAll('section[id]');
  const links=document.querySelectorAll('.nav-links a[href^="#"]');
  const obs=new IntersectionObserver(entries=>{
    entries.forEach(entry=>{
      if(entry.isIntersecting){
        const id=entry.target.id;
        links.forEach(l=>{
          l.classList.toggle('nav-active',l.getAttribute('href')==='#'+id);
        });
      }
    });
  },{threshold:0.35,rootMargin:'-80px 0px -30% 0px'});
  sections.forEach(s=>obs.observe(s));
})();

// ===== NAV =====
function toggleNav(){document.getElementById('mnav').classList.toggle('open');}
function closeNav(){document.getElementById('mnav').classList.remove('open');}

// ===== SEMESTER ACCORDION =====
function toggleSem(item){
  const body=item.querySelector('.sem-body');
  const open=item.classList.contains('open');
  document.querySelectorAll('.sem-item').forEach(i=>{i.classList.remove('open');i.querySelector('.sem-body').classList.remove('open');});
  if(!open){item.classList.add('open');body.classList.add('open');}
}

// ===== TABS =====
function switchPTab(btn,l){
  document.querySelectorAll('#ptabs .tab').forEach(t=>t.classList.remove('active'));btn.classList.add('active');
  document.querySelectorAll('#pgrid .pcard').forEach(c=>c.style.display=(l==='all'||c.dataset.l===l)?'block':'none');
}
function switchUTab(btn,u){
  document.querySelectorAll('#utabs .tab').forEach(t=>t.classList.remove('active'));btn.classList.add('active');
  document.querySelectorAll('#ugrid .ucard').forEach(c=>c.style.display=(u==='all'||c.dataset.u===u)?'block':'none');
}

// ===== BOOK TABS =====
function switchBookTab(btn,sem){
  document.querySelectorAll('#bookTabs .tab').forEach(t=>t.classList.remove('active'));btn.classList.add('active');
  document.querySelectorAll('.book-sem-section').forEach(s=>s.style.display=(sem==='all'||s.dataset.bsem===sem)?'block':'none');
}
function filterBooks(q){
  const lq=q.toLowerCase();
  document.querySelectorAll('.bcard').forEach(c=>{
    const txt=(c.querySelector('.btitle')?.textContent+c.querySelector('.bauthor')?.textContent+c.querySelector('.bdesc')?.textContent).toLowerCase();
    c.style.display=txt.includes(lq)?'flex':'none';
  });
}

// ===== Q&LA SECTION =====
function switchQlaMode(mode,btn){
  document.querySelectorAll('.qla-tab').forEach(t=>t.classList.remove('active'));btn.classList.add('active');
  document.getElementById('qla-browse').style.display=mode==='browse'?'block':'none';
  document.getElementById('qla-upload').style.display=mode==='upload'?'block':'none';
}
let activeQlaSem='all',activeQlaType='all';
function filterQla(sem,btn){
  activeQlaSem=sem;
  document.querySelectorAll('#qlaSemFilter .qla-sem-btn').forEach(b=>b.classList.remove('active'));btn.classList.add('active');
  applyQlaFilter();
}
function filterQlaType(type,btn){
  activeQlaType=type;
  document.querySelectorAll('#qlaTypeFilter .tab').forEach(b=>b.classList.remove('active'));btn.classList.add('active');
  applyQlaFilter();
}
function applyQlaFilter(){
  document.querySelectorAll('#qlaGrid .qla-card').forEach(c=>{
    const semOk=activeQlaSem==='all'||c.dataset.qlasem===activeQlaSem;
    const typeOk=activeQlaType==='all'||c.dataset.qlatype===activeQlaType;
    c.style.display=(semOk&&typeOk)?'block':'none';
  });
}
function submitQlaUpload(){
  const title=document.getElementById('qlaTitle').value;
  const type=document.getElementById('qlaType').value;
  const sem=document.getElementById('qlaSem').value;
  if(!title||!type||!sem){alert('Please fill in all required fields.');return;}
  const grid=document.getElementById('qlaGrid');
  const semMap={'Semester 1':'sem1','Semester 2':'sem2','Semester 3':'sem3','Semester 4':'sem4','Semester 5':'sem5','Semester 6':'sem6','Semester 7':'sem7','Semester 8':'sem8'};
  const typeMap={'Previous Year Question':'question','Lab Report':'lab','Assignment':'lab','Lecture Notes':'lab','Practical Manual':'lab'};
  const card=document.createElement('div');
  card.className='qla-card';card.dataset.qlasem=semMap[sem]||'sem1';card.dataset.qlatype=typeMap[type]||'question';
  card.innerHTML=`<span class="qla-type ${typeMap[type]==='question'?'q':'l'}">${type}</span><div class="qla-title">${title}</div><div class="qla-meta">${sem} • ${document.getElementById('qlaCourse').value||'N/A'} • ${document.getElementById('qlaYear').value||'2025'} • Pending Review</div><div class="qla-actions"><button class="qla-btn">👁️ Preview</button><button class="qla-btn primary">📥 Download</button></div>`;
  grid.appendChild(card);
  document.getElementById('qlaTitle').value='';document.getElementById('qlaType').value='';document.getElementById('qlaSem').value='';
  switchQlaMode('browse',document.querySelectorAll('.qla-tab')[0]);
  alert('✅ Submitted for review! It will appear after moderation.');
}
function previewQla(title){
  document.getElementById('previewTitle').textContent=title;
  document.getElementById('previewBody').innerHTML=`<div style="text-align:center;padding:40px;"><div style="font-size:64px;margin-bottom:16px;">📄</div><div style="font-size:15px;color:var(--text2);line-height:1.7;">This is a preview of <strong style="color:var(--text);">${title}</strong>.<br><br>In the full live version, the actual PDF/document would be displayed here.<br>Students can view, zoom, and download directly.</div><br><a href="#" class="btn btn-p" style="display:inline-flex;">📥 Download</a></div>`;
  document.getElementById('previewModal').classList.add('open');
}

// ===== UNIVERSITY EXPAND =====
function toggleUniDetails(btn){
  const extra=btn.nextElementSibling;
  const isOpen=extra.classList.contains('open');
  extra.classList.toggle('open');
  btn.textContent=isOpen?'▼ Show Programs & Scholarships':'▲ Hide Details';
}

// ===== UPLOAD =====
function dOver(e){e.preventDefault();var z=document.getElementById('uploadZone2');if(z)z.classList.add('dragover');}
function dLeave(){var z=document.getElementById('uploadZone2');if(z)z.classList.remove('dragover');}
function dDrop(e){e.preventDefault();dLeave();if(e.dataTransfer&&e.dataTransfer.files.length)showFiles(e.dataTransfer.files,'uploadedFiles2');}
function handleFiles(i){showFiles(i.files);}
function showFiles(files,containerId){
  const c=document.getElementById(containerId||'uploadedFiles2');
  const MAX_SIZE=1*1024*1024*1024;
  Array.from(files).forEach(f=>{
    if(f.size>MAX_SIZE){
      alert('❌ "'+f.name+'" exceeds the 1 GB size limit ('+((f.size/1024/1024/1024).toFixed(2))+' GB). Please upload a smaller file.');
      return;
    }
    const el=document.createElement('div');el.className='fitem';
    const sizeMB=f.size/1024/1024;
    const sizeLabel=sizeMB>=1024?((sizeMB/1024).toFixed(2)+' GB'):(sizeMB.toFixed(1)+' MB');
    el.innerHTML=`<div class="ficon">📄</div><div class="finfo"><div class="fname">${f.name}</div><div class="fmeta">${sizeLabel} • Ready</div></div><div class="fact"><span style="color:var(--accent3);font-size:18px">✓</span></div>`;
    c.appendChild(el);
  });
}
function dOver2(e){e.preventDefault();document.getElementById('uploadZone2').classList.add('dragover');}
function dLeave2(){document.getElementById('uploadZone2').classList.remove('dragover');}
function dDrop2(e){e.preventDefault();document.getElementById('uploadZone2').classList.remove('dragover');if(e.dataTransfer.files.length)showFiles(e.dataTransfer.files,'uploadedFiles2');}
function handleFiles2(i){showFiles(i.files,'uploadedFiles2');}
function dOver3(e){e.preventDefault();document.getElementById('uploadZone3').classList.add('dragover');}
function dLeave3(){document.getElementById('uploadZone3').classList.remove('dragover');}
function dDrop3(e){e.preventDefault();document.getElementById('uploadZone3').classList.remove('dragover');if(e.dataTransfer.files.length)showFiles(e.dataTransfer.files,'uploadedFiles3');}
function handleFiles3(i){showFiles(i.files,'uploadedFiles3');}
function submitUpload3(){
  const title=document.getElementById('uTitle3').value;const cat=document.getElementById('uCat3').value;
  if(!title||!cat){alert('Please fill required fields.');return;}
  alert('✅ Resource submitted! Nasif will review and add it to the library.');
  document.getElementById('uTitle3').value='';document.getElementById('uCat3').value='';document.getElementById('uDesc3').value='';
}

// ===== FEEDBACK =====
function sendFeedback(){
  const name=document.getElementById('fb-name').value;
  const type=document.getElementById('fb-type').value;
  const msg=document.getElementById('fb-msg').value;
  if(!msg){alert('Please write a message first!');return;}
  const subject=encodeURIComponent(`[BAUST CSE Hub] ${type||'Feedback'} from ${name||'Student'}`);
  const body=encodeURIComponent(`Name: ${name||'Anonymous'}\nType: ${type||'Feedback'}\n\nMessage:\n${msg}\n\n---\nSent via BAUST Khulna CSE Hub`);
  window.open(`https://mail.google.com/mail/?view=cm&to=mushfiqulalam14@gmail.com&su=${subject}&body=${body}`,'_blank');
  document.getElementById('fb-name').value='';document.getElementById('fb-type').value='';document.getElementById('fb-msg').value='';
  alert('✅ Gmail compose opened!');
}

// ===== MODAL =====
function closeModal(){document.getElementById('previewModal').classList.remove('open');}
document.getElementById('previewModal').addEventListener('click',function(e){if(e.target===this)closeModal();});

// ===== SEARCH =====
const searchData=[
  {title:'Introduction to Computer Science',sub:'Semester 1 • CSE-101',section:'courses',icon:'📚',tag:'Course'},
  {title:'Digital Logic Design',sub:'Semester 2 • CSE-103',section:'courses',icon:'🔌',tag:'Course'},
  {title:'Structured Programming C',sub:'Semester 2 • CSE-105',section:'courses',icon:'💻',tag:'Course'},
  {title:'Data Structures & Algorithms I',sub:'Semester 3 • CSE-203',section:'courses',icon:'📊',tag:'Course'},
  {title:'Object Oriented Programming Java',sub:'Semester 3 • CSE-205',section:'courses',icon:'☕',tag:'Course'},
  {title:'Theory of Computation',sub:'Semester 3 • CSE-217',section:'courses',icon:'🤖',tag:'Course'},
  {title:'Operating Systems',sub:'Semester 4 • CSE-307',section:'courses',icon:'⚙️',tag:'Course'},
  {title:'Computer Architecture',sub:'Semester 4 • CSE-305',section:'courses',icon:'🖥️',tag:'Course'},
  {title:'Database Management Systems',sub:'Semester 5 • CSE-401',section:'courses',icon:'🗄️',tag:'Course'},
  {title:'Computer Networks',sub:'Semester 5 • CSE-403',section:'courses',icon:'🌐',tag:'Course'},
  {title:'Machine Learning',sub:'Semester 7 • CSE-601',section:'courses',icon:'🧠',tag:'Course'},
  {title:'Introduction to Algorithms CLRS',sub:'Essential Book • All Semesters',section:'books',icon:'📖',tag:'Book'},
  {title:'Operating Systems Three Easy Pieces',sub:'Free Online Book',section:'books',icon:'📕',tag:'Book'},
  {title:'Automate the Boring Stuff Python',sub:'Free Online Book',section:'books',icon:'🐍',tag:'Book'},
  {title:'Deep Learning Goodfellow',sub:'Free Online Book • Sem 7',section:'books',icon:'🔬',tag:'Book'},
  {title:'LeetCode — Coding Practice',sub:'Best for Interviews',section:'coding',icon:'🟡',tag:'Platform'},
  {title:'Codeforces — Competitive Programming',sub:'Contests',section:'coding',icon:'🔵',tag:'Platform'},
  {title:'MIT Massachusetts Institute of Technology',sub:'USA • QS #1',section:'universities',icon:'🇺🇸',tag:'University'},
  {title:'Stanford University',sub:'USA • QS #5',section:'universities',icon:'🇺🇸',tag:'University'},
  {title:'TU Munich Germany',sub:'Europe • Free Tuition',section:'universities',icon:'🇩🇪',tag:'University'},
  {title:'BUET Bangladesh',sub:'Bangladesh • Rank #1',section:'universities',icon:'🇧🇩',tag:'University'},
  {title:'KUET Khulna',sub:'Khulna • Rank #4',section:'universities',icon:'🇧🇩',tag:'University'},
  {title:'Previous Year Questions',sub:'Q&Lab Section',section:'qla',icon:'📄',tag:'Q&Lab'},
  {title:'Lab Reports',sub:'Q&Lab Section',section:'qla',icon:'🧪',tag:'Q&Lab'},
  {title:'bKash Internship Bangladesh',sub:'Fintech Internship',section:'internships',icon:'🐯',tag:'Career'},
  {title:'Google STEP Internship',sub:'Global Internship',section:'internships',icon:'🧡',tag:'Career'},
  {title:'GSoC Open Source',sub:'Paid Remote Program',section:'internships',icon:'🌟',tag:'Career'},
];
function openSearch(){document.getElementById('searchOv').classList.add('open');setTimeout(()=>document.getElementById('searchInput').focus(),100);}
function closeSearch(){document.getElementById('searchOv').classList.remove('open');document.getElementById('searchInput').value='';document.getElementById('searchResults').innerHTML='<div class="search-empty">Start typing to search across all content…</div>';}
function handleSearchOvClick(e){if(e.target===document.getElementById('searchOv'))closeSearch();}
function doSearch(q){
  const r=document.getElementById('searchResults');
  if(!q.trim()){r.innerHTML='<div class="search-empty">Start typing to search across all content…</div>';return;}
  const lq=q.toLowerCase();
  const results=searchData.filter(d=>(d.title+d.sub).toLowerCase().includes(lq)).slice(0,8);
  if(!results.length){r.innerHTML='<div class="search-empty">No results found. Try a different keyword.</div>';return;}
  r.innerHTML=results.map(d=>`<a class="sr-item" href="#${d.section}" onclick="closeSearch()"><div class="sr-icon">${d.icon}</div><div class="flex-1"><div class="sr-title">${highlight(d.title,lq)}</div><div class="sr-sub">${d.sub}</div></div><span class="sr-tag">${d.tag}</span></a>`).join('');
}
function highlight(text, q) {
  if (!q) return text;
  try {
    var escaped = q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    return text.replace(new RegExp('(' + escaped + ')', 'gi'),
      '<mark style="background:rgba(3,105,161,0.18);color:var(--accent);border-radius:3px;padding:0 2px">$1</mark>');
  } catch(e) { return text; }
}

// ===== YOUTUBE CHANNELS FILTER =====
let activeYtSem = 'all';
let activeYtSearch = '';
function filterYtSem(sem, btn) {
  activeYtSem = sem;
  document.querySelectorAll('#ytFilterBar .tab').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
  applyYtFilter();
}
function filterYtChannels(q) {
  activeYtSearch = q.toLowerCase().trim();
  applyYtFilter();
}
function applyYtFilter() {
  let visible = 0;
  document.querySelectorAll('#ytGrid .yt-card').forEach(card => {
    const semOk = activeYtSem === 'all' || (card.dataset.ytsem || '').includes(activeYtSem);
    const name = (card.dataset.ytname || '') + ' ' + (card.querySelector('.yt-channel-name') || {}).textContent + ' ' + (card.querySelector('.yt-desc') || {}).textContent;
    const searchOk = !activeYtSearch || name.toLowerCase().includes(activeYtSearch);
    const show = semOk && searchOk;
    card.style.display = show ? '' : 'none';
    if (show) visible++;
  });
  const noRes = document.getElementById('ytNoResults');
  if (noRes) noRes.style.display = visible === 0 ? 'block' : 'none';
}


// ============================================================
// FACULTY PORTAL
// ============================================================
var fpState = {
  loggedIn: false,
  user: null,
  classrooms: [],
  materials: [],
  announcements: [],
  notifications: [
    {id:1, icon:'📩', msg:'New feedback from a student on Week 3 assignment', time:'2 hrs ago', unread:true},
    {id:2, icon:'📢', msg:'Your announcement was seen by 58 students', time:'5 hrs ago', unread:true},
    {id:3, icon:'✅', msg:'Material "Linked Lists Lab" published successfully', time:'1 day ago', unread:true},
  ]
};

var fpClassColors = [
  'linear-gradient(135deg,#0369a1,#6366f1)',
  'linear-gradient(135deg,#059669,#0369a1)',
  'linear-gradient(135deg,#d97706,#db2777)',
  'linear-gradient(135deg,#6366f1,#db2777)',
  'linear-gradient(135deg,#059669,#6366f1)',
  'linear-gradient(135deg,#0284c7,#059669)',
];

var fpMatIcons = {
  'Lecture Slides':'📊', 'Lecture Notes':'📝', 'Assignment':'📋',
  'Lab Sheet':'🧪', 'Past Question':'📄', 'Reading Material':'📖',
  'Solution Sheet':'✅', 'Project Brief':'🛠️', 'Other':'📁'
};

var fpMatColors = {
  'Lecture Slides':'rgba(3,105,161,0.12)', 'Lecture Notes':'rgba(99,102,241,0.12)',
  'Assignment':'rgba(217,119,6,0.12)', 'Lab Sheet':'rgba(5,150,105,0.12)',
  'Past Question':'rgba(219,39,119,0.12)', 'Reading Material':'rgba(3,105,161,0.1)',
  'Solution Sheet':'rgba(5,150,105,0.12)', 'Project Brief':'rgba(99,102,241,0.12)', 'Other':'rgba(107,114,128,0.1)'
};

function fpSwitchAuth(mode) {
  document.getElementById('fp-login-form').style.display = mode==='login' ? '' : 'none';
  document.getElementById('fp-register-form').style.display = mode==='register' ? '' : 'none';
  document.querySelectorAll('.fp-tab').forEach(function(t,i){ t.classList.toggle('active', (mode==='login'&&i===0)||(mode==='register'&&i===1)); });
}

function fpTogglePass(id) {
  var el = document.getElementById(id);
  el.type = el.type === 'password' ? 'text' : 'password';
}

function fpLogin() {
  var email = (document.getElementById('fp-email').value||'').trim();
  var pass = (document.getElementById('fp-pass').value||'').trim();
  var err = document.getElementById('fp-login-err');
  if (!email) { err.style.display=''; err.textContent='Please enter your email.'; return; }
  if (!email.includes('@')) { err.style.display=''; err.textContent='Please enter a valid email address.'; return; }
  if (pass !== 'faculty123') { err.style.display=''; err.textContent='Incorrect password. (Demo: use "faculty123")'; return; }
  err.style.display='none';
  var name = email.split('@')[0].replace(/\./g,' ').replace(/\b\w/g,function(c){return c.toUpperCase();});
  fpState.loggedIn = true;
  fpState.user = { name: name, email: email, role: 'Assistant Professor', dept: 'CSE' };
  fpShowDashboard();
}

function fpRegister() {
  var fname = (document.getElementById('fp-fname').value||'').trim();
  var lname = (document.getElementById('fp-lname').value||'').trim();
  var email = (document.getElementById('fp-reg-email').value||'').trim();
  var dept = (document.getElementById('fp-dept').value||'').trim();
  var desig = (document.getElementById('fp-desig').value||'').trim();
  var pass = (document.getElementById('fp-reg-pass').value||'').trim();
  var err = document.getElementById('fp-reg-err');
  if (!fname||!lname) { err.style.display=''; err.textContent='Please enter your full name.'; return; }
  if (!email.includes('@')) { err.style.display=''; err.textContent='Please enter a valid email.'; return; }
  if (!dept) { err.style.display=''; err.textContent='Please select your department.'; return; }
  if (!desig) { err.style.display=''; err.textContent='Please select your designation.'; return; }
  if (pass.length < 6) { err.style.display=''; err.textContent='Password must be at least 6 characters.'; return; }
  err.style.display='none';
  fpState.loggedIn = true;
  fpState.user = { name: fname+' '+lname, email: email, role: desig, dept: dept.split(' ')[0] };
  fpShowDashboard();
}

function fpShowDashboard() {
  document.getElementById('fp-auth-gate').style.display = 'none';
  document.getElementById('fp-dashboard').style.display = '';
  var u = fpState.user;
  var initials = u.name.split(' ').slice(0,2).map(function(w){return w[0]||'';}).join('').toUpperCase();
  document.getElementById('fp-avatar-initials').textContent = initials;
  document.getElementById('fp-user-name').textContent = u.name;
  document.getElementById('fp-user-role').textContent = u.role + ' · ' + u.dept;
  fpUpdateStats();
  fpRenderClassrooms();
  fpRenderNotifications();
}

function fpLogout() {
  fpState.loggedIn = false;
  document.getElementById('fp-dashboard').style.display = 'none';
  document.getElementById('fp-auth-gate').style.display = '';
  document.getElementById('fp-email').value = '';
  document.getElementById('fp-pass').value = '';
  document.getElementById('fp-notif-panel').style.display = 'none';
}

function fpUpdateStats() {
  document.getElementById('fp-stat-uploads').textContent = fpState.materials.length;
  document.getElementById('fp-stat-courses').textContent = fpState.classrooms.length;
  document.getElementById('fp-stat-announce').textContent = fpState.announcements.length;
}

function fpShowTab(tab) {
  ['classrooms','upload','announce','materials'].forEach(function(t) {
    var panel = document.getElementById('fp-tab-'+t);
    var btn = document.getElementById('tab-'+t);
    if (panel) panel.style.display = t===tab ? '' : 'none';
    if (btn) btn.classList.toggle('active', t===tab);
  });
}

function fpShowCreateClass() {
  document.getElementById('fp-create-class-form').style.display = '';
  document.getElementById('fp-create-class-form').scrollIntoView({behavior:'smooth',block:'nearest'});
}
function fpHideCreateClass() { document.getElementById('fp-create-class-form').style.display='none'; }

function fpCreateClassroom() {
  var name = (document.getElementById('cc-name').value||'').trim();
  var code = (document.getElementById('cc-code').value||'').trim();
  var sem = document.getElementById('cc-sem').value;
  var credits = document.getElementById('cc-credits').value;
  var desc = (document.getElementById('cc-desc').value||'').trim();
  if (!name||!code) { alert('Please enter course name and code.'); return; }
  var cls = { id: Date.now(), name:name, code:code, sem:sem||'General', credits:credits||'3', desc:desc, materials:0, students: Math.floor(Math.random()*30)+20, colorIdx: fpState.classrooms.length % fpClassColors.length };
  fpState.classrooms.push(cls);
  fpHideCreateClass();
  document.getElementById('cc-name').value=''; document.getElementById('cc-code').value='';
  document.getElementById('cc-sem').value=''; document.getElementById('cc-desc').value='';
  fpRenderClassrooms();
  fpUpdateStats();
  fpRefreshClassDropdowns();
}

function fpRenderClassrooms() {
  var grid = document.getElementById('fp-classrooms-grid');
  var empty = document.getElementById('fp-no-classrooms');
  if (!fpState.classrooms.length) { grid.innerHTML=''; empty.style.display=''; return; }
  empty.style.display='none';
  grid.innerHTML = fpState.classrooms.map(function(c) {
    var matCount = fpState.materials.filter(function(m){return m.classId===c.id;}).length;
    return '<div class="fp-class-card">'+
      '<div class="fp-class-header" style="background:'+fpClassColors[c.colorIdx]+';"><div class="fp-class-pattern"></div>'+
      '<div class="fp-class-code">'+c.code+'</div>'+
      '<div class="fp-class-name">'+c.name+'</div>'+
      '<div class="fp-class-sem">'+c.sem+' · '+c.credits+' Credits</div></div>'+
      '<div class="fp-class-body">'+
      '<div class="fp-class-meta">'+
      '<div class="fp-class-stat">Materials: <span>'+matCount+'</span></div>'+
      '<div class="fp-class-stat">Students: <span>'+c.students+'</span></div></div>'+
      '<div class="fp-class-actions">'+
      '<div class="fp-class-btn primary" onclick="fpGoUploadFor('+c.id+')">📤 Upload</div>'+
      '<div class="fp-class-btn" onclick="fpDeleteClass('+c.id+')">🗑 Delete</div>'+
      '</div></div></div>';
  }).join('');
}

function fpGoUploadFor(classId) {
  fpShowTab('upload');
  var sel = document.getElementById('fp-mat-class');
  if (sel) sel.value = classId;
}

function fpDeleteClass(id) {
  if (!confirm('Delete this classroom? Associated materials will also be removed.')) return;
  fpState.classrooms = fpState.classrooms.filter(function(c){return c.id!==id;});
  fpState.materials = fpState.materials.filter(function(m){return m.classId!==id;});
  fpRenderClassrooms(); fpRenderMaterials(); fpUpdateStats(); fpRefreshClassDropdowns();
}

function fpRefreshClassDropdowns() {
  var opts = '<option value="">Select classroom…</option>'+fpState.classrooms.map(function(c){return '<option value="'+c.id+'">'+c.name+' ('+c.code+')</option>';}).join('');
  var annOpts = '<option value="all">📢 All Classrooms</option>'+fpState.classrooms.map(function(c){return '<option value="'+c.id+'">'+c.name+'</option>';}).join('');
  document.getElementById('fp-mat-class').innerHTML = opts;
  document.getElementById('fp-ann-class').innerHTML = annOpts;
}

var fpSelectedFiles = [];
function fpDOver(e) { e.preventDefault(); document.getElementById('fp-upload-zone').classList.add('drag-over'); }
function fpDLeave() { document.getElementById('fp-upload-zone').classList.remove('drag-over'); }
function fpDrop(e) { e.preventDefault(); fpDLeave(); fpAddFiles(e.dataTransfer.files); }
function fpHandleFiles(input) { fpAddFiles(input.files); input.value=''; }
function fpAddFiles(files) {
  for (var i=0;i<files.length;i++) { fpSelectedFiles.push(files[i]); }
  fpRenderFileList();
}
function fpRenderFileList() {
  var list = document.getElementById('fp-file-list');
  if (!fpSelectedFiles.length) { list.innerHTML=''; return; }
  list.innerHTML = fpSelectedFiles.map(function(f,i){
    var size = f.size > 1024*1024 ? (f.size/1024/1024).toFixed(1)+' MB' : Math.round(f.size/1024)+' KB';
    return '<div class="fitem"><span class="ficon">📄</span><div class="fmeta"><div class="fname">'+f.name+'</div><div class="fsize">'+size+'</div></div><button class="fdel" onclick="fpRemoveFile('+i+')">✕</button></div>';
  }).join('');
}
function fpRemoveFile(i) { fpSelectedFiles.splice(i,1); fpRenderFileList(); }

function fpSubmitMaterial() {
  var title = (document.getElementById('fp-mat-title').value||'').trim();
  var classId = document.getElementById('fp-mat-class').value;
  var type = document.getElementById('fp-mat-type').value;
  var week = (document.getElementById('fp-mat-week').value||'').trim();
  var due = document.getElementById('fp-mat-due').value;
  var notes = (document.getElementById('fp-mat-notes').value||'').trim();
  if (!title) { alert('Please enter a material title.'); return; }
  if (!classId) { alert('Please select a classroom.'); return; }
  if (!fpSelectedFiles.length) { alert('Please select at least one file to upload.'); return; }
  var cls = fpState.classrooms.find(function(c){return String(c.id)===String(classId);});
  var mat = {
    id: Date.now(), title:title, classId:parseInt(classId), className: cls ? cls.name : 'Unknown',
    type:type, week:week, due:due, notes:notes,
    files: fpSelectedFiles.map(function(f){return f.name;}),
    uploadedAt: new Date().toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'})
  };
  fpState.materials.push(mat);
  if (cls) cls.materials = (cls.materials||0)+1;
  fpSelectedFiles = [];
  document.getElementById('fp-mat-title').value=''; document.getElementById('fp-mat-week').value='';
  document.getElementById('fp-mat-due').value=''; document.getElementById('fp-mat-notes').value='';
  fpRenderFileList();
  fpRenderMaterials(); fpRenderClassrooms(); fpUpdateStats();
  fpShowTab('materials');
  alert('✅ Material "'+title+'" published successfully!');
}

function fpRenderMaterials(filtered) {
  var list = document.getElementById('fp-materials-list');
  var mats = filtered || fpState.materials;
  if (!mats.length) {
    list.innerHTML = '<div class="fp-empty"><div style="font-size:48px;margin-bottom:16px;">📂</div><div style="font-size:16px;font-weight:700;margin-bottom:8px;color:var(--text);">No materials yet</div><div style="font-size:14px;color:var(--text3);">Switch to "Upload Material" tab to add your first resource</div></div>';
    return;
  }
  list.innerHTML = mats.map(function(m) {
    var icon = fpMatIcons[m.type]||'📁';
    var color = fpMatColors[m.type]||'rgba(107,114,128,0.1)';
    var files = m.files.slice(0,2).join(', ')+(m.files.length>2?' +more':'');
    return '<div class="fp-mat-item">'+
      '<div class="fp-mat-icon" style="background:'+color+'">'+icon+'</div>'+
      '<div class="fp-mat-info">'+
        '<div class="fp-mat-title">'+m.title+'</div>'+
        '<div class="fp-mat-meta">'+
          '<span class="fp-mat-tag" style="background:'+color+';color:var(--accent)">'+m.type+'</span>'+
          '<span style="font-size:11px;color:var(--text3);">'+m.className+'</span>'+
          (m.week?'<span style="font-size:11px;color:var(--text3);">'+m.week+'</span>':'')+
          '<span style="font-size:11px;color:var(--text3);">'+m.uploadedAt+'</span>'+
        '</div>'+
        '<div style="font-size:11px;color:var(--text3);margin-top:3px;font-family:\'JetBrains Mono\',monospace;">📎 '+files+'</div>'+
      '</div>'+
      '<div class="fp-mat-actions">'+
        '<button class="fp-mat-act">✏️ Edit</button>'+
        '<button class="fp-mat-act del" onclick="fpDeleteMat('+m.id+')">🗑</button>'+
      '</div>'+
    '</div>';
  }).join('');
}

function fpDeleteMat(id) {
  if (!confirm('Remove this material?')) return;
  fpState.materials = fpState.materials.filter(function(m){return m.id!==id;});
  fpRenderMaterials(); fpUpdateStats(); fpRenderClassrooms();
}

function fpFilterMaterials() {
  var q = (document.getElementById('fp-mat-search').value||'').toLowerCase();
  var type = document.getElementById('fp-mat-filter-type').value;
  var filtered = fpState.materials.filter(function(m){
    var matchSearch = !q || m.title.toLowerCase().includes(q) || m.className.toLowerCase().includes(q);
    var matchType = type==='all' || m.type===type;
    return matchSearch && matchType;
  });
  fpRenderMaterials(filtered);
}

function fpPostAnnouncement() {
  var classId = document.getElementById('fp-ann-class').value;
  var title = (document.getElementById('fp-ann-title').value||'').trim();
  var body = (document.getElementById('fp-ann-body').value||'').trim();
  var priority = document.getElementById('fp-ann-priority').value;
  var expiry = document.getElementById('fp-ann-expiry').value;
  if (!title||!body) { alert('Please fill in the announcement title and message.'); return; }
  var targetName = classId==='all' ? 'All Classrooms' : (fpState.classrooms.find(function(c){return String(c.id)===classId;})||{}).name||'Unknown';
  var ann = { id:Date.now(), title:title, body:body, priority:priority, classId:classId, targetName:targetName, expiry:expiry, postedAt: new Date().toLocaleDateString('en-US',{month:'short',day:'numeric'}) };
  fpState.announcements.unshift(ann);
  document.getElementById('fp-ann-title').value=''; document.getElementById('fp-ann-body').value='';
  fpRenderAnnouncements(); fpUpdateStats();
}

function fpRenderAnnouncements() {
  var list = document.getElementById('fp-ann-list');
  if (!fpState.announcements.length) {
    list.innerHTML='<div class="fp-empty" style="padding:24px 0;"><div style="font-size:36px;margin-bottom:10px;">📢</div><div style="font-size:13px;color:var(--text3);">No announcements posted yet</div></div>';
    return;
  }
  var icons = {normal:'🟢',important:'🟡',urgent:'🔴'};
  list.innerHTML = fpState.announcements.map(function(a){
    return '<div class="fp-ann-item '+a.priority+'">'+
      '<button class="fp-ann-del" onclick="fpDeleteAnn('+a.id+')">✕</button>'+
      '<div class="fp-ann-title">'+icons[a.priority]+' '+a.title+'</div>'+
      '<div class="fp-ann-body">'+a.body+'</div>'+
      '<div class="fp-ann-meta"><span>'+a.targetName+'</span><span>·</span><span>'+a.postedAt+'</span>'+(a.expiry?'<span>· Expires '+a.expiry+'</span>':'')+'</div>'+
    '</div>';
  }).join('');
}

function fpDeleteAnn(id) {
  fpState.announcements = fpState.announcements.filter(function(a){return a.id!==id;});
  fpRenderAnnouncements(); fpUpdateStats();
}

function fpRenderNotifications() {
  var list = document.getElementById('fp-notif-list');
  var dot = document.getElementById('fp-notif-dot');
  var unread = fpState.notifications.filter(function(n){return n.unread;}).length;
  dot.textContent = unread; dot.style.display = unread ? '' : 'none';
  list.innerHTML = fpState.notifications.map(function(n){
    return '<div class="fp-notif-item'+(n.unread?' unread':'')+'">'+
      '<div class="fp-notif-icon" style="background:rgba(3,105,161,0.1);">'+n.icon+'</div>'+
      '<div class="fp-notif-text"><div class="fp-notif-msg">'+n.msg+'</div><div class="fp-notif-time">'+n.time+'</div></div>'+
    '</div>';
  }).join('');
}

function fpToggleNotif() {
  var panel = document.getElementById('fp-notif-panel');
  panel.style.display = panel.style.display==='none' ? '' : 'none';
}

function fpMarkAllRead() {
  fpState.notifications.forEach(function(n){n.unread=false;});
  fpRenderNotifications();
  document.getElementById('fp-notif-panel').style.display='none';
}

document.addEventListener('click', function(e) {
  var panel = document.getElementById('fp-notif-panel');
  var bell = document.getElementById('fp-notif-bell');
  if (panel && bell && !panel.contains(e.target) && !bell.contains(e.target)) {
    panel.style.display = 'none';
  }
});

document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape') {
    var panel = document.getElementById('fp-notif-panel');
    if (panel) panel.style.display='none';
  }

}); // end sections:ready
