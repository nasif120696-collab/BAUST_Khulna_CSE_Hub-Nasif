# BAUST Khulna CSE Hub

A student resource hub for the CSE Department at BAUST Khulna — organized as a real multi-file project.

---

## 📁 Project Structure

```
baust-cse-hub/
├── index.html              ← Main entry point (shell only)
│
├── css/
│   └── main.css            ← All styles (themes, layout, animations)
│
├── js/
│   ├── loader.js           ← Fetches & injects section HTML files
│   └── main.js             ← All app logic (theme, nav, modals, portals…)
│
└── sections/               ← Each page section as its own HTML fragment
    ├── nav.html            ← Top navbar + mobile nav + search overlay
    ├── hero.html           ← Hero / landing section
    ├── courses.html        ← Course Roadmap (Semesters 1–8 accordion)
    ├── books.html          ← Virtual Book Library
    ├── qla.html            ← Q&A / Lab Reports
    ├── coding.html         ← Coding Practice links
    ├── projects.html       ← Project Ideas
    ├── internships.html    ← Internships & Career
    ├── universities.html   ← University listings
    ├── upload.html         ← Upload Resources panel
    ├── faculty.html        ← Faculty Portal (login + dashboard)
    ├── youtube.html        ← YouTube Channel recommendations
    ├── feedback.html       ← Feedback form section
    └── footer.html         ← Creator credit, preview modal, footer
```

---

## 🚀 How to Run

> **A local server is required.** Browsers block `fetch()` requests on `file://` URLs, so you can't just double-click `index.html`.

### Option 1 — VS Code Live Server (easiest)
1. Install the **Live Server** extension in VS Code
2. Open the `baust-cse-hub/` folder
3. Right-click `index.html` → **"Open with Live Server"**

### Option 2 — Node.js
```bash
npx serve .
# Then open http://localhost:3000
```

### Option 3 — Python
```bash
python -m http.server 8080
# Then open http://localhost:8080
```

---

## ⚙️ How It Works

`loader.js` runs before `main.js`. It finds every `<div data-include="sections/xxx.html">` in `index.html`, fetches the file, and replaces the placeholder with the actual HTML — in order, sequentially. Once all sections are injected, it fires a `sections:ready` custom event.

`main.js` listens for `sections:ready` before touching any DOM elements, so everything works correctly regardless of network speed.

---

## 🛠️ Extending the Project

**Add a new section:**
1. Create `sections/your-section.html`
2. Add `<div data-include="sections/your-section.html"></div>` to `index.html` at the right position
3. Add any new styles to `css/main.css`
4. Add any new JS functions to `js/main.js` inside the `sections:ready` listener

**Add more CSS files:**  
Add `<link rel="stylesheet" href="css/your-file.css">` in the `<head>` of `index.html`.

**Add more JS files:**  
Add `<script src="js/your-file.js"></script>` before `</body>` in `index.html`, after `loader.js` and `main.js`.
